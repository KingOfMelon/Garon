package de.Garon_;

import de.Garon_.blocks.garon_table;
import de.Garon_.handler.GUIHandler;
import de.Garon_.proxies.GaronServer;
import net.minecraft.block.Block;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.Mod.Instance;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.registry.GameRegistry;

@Mod(modid = garon.MODID)
public class garon {
	
	public static final String MODID = "garon";

	@SidedProxy(clientSide = "de.Garon_.proxies.GaronClient", serverSide = "de.Garon_.proxies.GaronServer")
	public static GaronServer PROXY;
	
	@Instance(MODID)
	public static garon INSTANCE;
	
	public static final int GUI_TABLE = 0;
	
	public static Block garon_table = new garon_table();
	
	@EventHandler
	public void preInit(FMLPreInitializationEvent preevent) {
		
		GameRegistry.registerBlock(garon_table, "garon_table");
		
	}
	
	@EventHandler
	public void init(FMLInitializationEvent event) {
		
		NetworkRegistry.INSTANCE.registerGuiHandler(INSTANCE, new GUIHandler());
	
	}
	
	@EventHandler
	public void posInit(FMLPostInitializationEvent posevent) {
		PROXY.registerModels();
	}
		
		
}
