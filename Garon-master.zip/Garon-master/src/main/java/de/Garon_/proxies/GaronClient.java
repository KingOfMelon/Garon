package de.Garon_.proxies;

import de.Garon_.garon;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.item.Item;

public class GaronClient extends GaronServer {
	
	public void registerRenderThings() {
		
	}
	
	public void registerModels() {
		
		Minecraft.getMinecraft().getRenderItem().getItemModelMesher().register(Item.getItemFromBlock(garon.garon_table), 0, new ModelResourceLocation("garon:garon_table", "inventory"));

		
	}

}