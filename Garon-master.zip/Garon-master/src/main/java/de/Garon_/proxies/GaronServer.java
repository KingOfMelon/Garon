package de.Garon_.proxies;

public class GaronServer {

	public void registerRenderThings() {
		
	}
	
	public void registerModels() {
		//Client
	}

}
